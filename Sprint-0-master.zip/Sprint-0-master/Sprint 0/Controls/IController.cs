﻿using Microsoft.Xna.Framework.Input;
using Sprint_0.Commands;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint_0.Controls
{
    internal interface IController
    {
        void Update();
    }
}
